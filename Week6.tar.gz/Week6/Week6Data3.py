#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Tue Jul  5 18:22:09 2022

@author: fatemeh
"""

from schema import Regex, Schema, SchemaError
import yaml
ip4_regex = r"^(?:[0-9]{1,3}\.){3}[0-9]{1,3}$"
config_schema = Schema({
    "servers": [
        {"host": Regex(ip4_regex), "port": int}
        ]
    })
conf_as_yaml = """
servers:
    - host: 146.180.127.85
      port: 5000
    - host: 89.79.252.148
      port: 5001
"""
configuration = yaml.safe_load(conf_as_yaml)
try:
    config_schema.validate(configuration)
    print("Configuration is valid.")
except SchemaError as se:
    raise se