#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Sun Jul 31 11:42:00 2022

@author: fatemeh
"""





import numpy as np

from sklearn.model_selection import StratifiedKFold
import numpy
# fix random seed for reproducibility




import math




from sklearn.impute import SimpleImputer
from pprint import pprint


#import pandas as pd
from sklearn.preprocessing import MinMaxScaler
#from sklearn.model_selection import train_test_split
from sklearn.metrics import classification_report, confusion_matrix
from sklearn.ensemble import GradientBoostingClassifier
#from sklearn.cross_validation import train_test_split 
import numpy as np 

#train_data = pd.read_csv("train.csv")
#test_data = pd.read_csv("test.csv")

# roc curve and auc score
from sklearn.datasets import make_classification
from sklearn.neighbors import KNeighborsClassifier
from sklearn.ensemble import RandomForestClassifier
from sklearn.model_selection import train_test_split
from sklearn.metrics import roc_curve
from sklearn.metrics import roc_auc_score
#import Tkinter as tk





from sklearn.ensemble import GradientBoostingClassifier
from sklearn.metrics import classification_report
#from sklearn.grid_search import GridSearchCV

import numpy as np 
#import matplotlib.pyplot as plt 



from sklearn.preprocessing import MinMaxScaler

from sklearn.model_selection  import train_test_split  #mohemen in shekli bashe






import pandas as pd
#data=pd.read_csv("prebp40.csv",delimiter=";" ,decimal="."),sep='\t'
data=pd.read_csv("cust_seg1.csv"  )


#from sklearn.model_selection import train_test_split




 
data=data.replace(' NA','np.nan')
data=data.replace(' ',0)



# data['Baseline_previousseasoninjury']=data['Baseline_previousseasoninjury'].replace('OUI, mais participation complète à l entrainement ou en compétition, malgré une blessure/problème physique',	1)
# data['Baseline_previousseasoninjury']=data['Baseline_previousseasoninjury'].replace('OUI, mais participation réduite à l entrainement ou en compétition, à ...',	1)






X1=data




from sklearn.experimental import enable_iterative_imputer
from sklearn.impute import IterativeImputer
#imp = IterativeImputer(max_iter=10, random_state=0)
from sklearn.impute import KNNImputer
imp = KNNImputer(n_neighbors=2, weights="uniform")
imp.fit(X1)
SimpleImputer()
# X = [[np.nan, 2], [6, np.nan], [7, 6]]
print(imp.transform(X1))
 #imp.fit(Y)
 #SimpleImputer()
# X = [[np.nan, 2], [6, np.nan], [7, 6]]








imp = IterativeImputer(max_iter=10, random_state=0)

imp.fit(X1)
SimpleImputer()
# X = [[np.nan, 2], [6, np.nan], [7, 6]]
print(imp.transform(X1))
 #imp.fit(Y)
 #SimpleImputer()
# X = [[np.nan, 2], [6, np.nan], [7, 6]]












